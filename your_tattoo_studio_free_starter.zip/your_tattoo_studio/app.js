const designs = [
 {id:1,name:"Moon phases",style:"Fine line",art:"moon"},
 {id:2,name:"Wild rose",style:"Nature",art:"rose"},
 {id:3,name:"Serpent",style:"Traditional",art:"snake"},
 {id:4,name:"Solar geometry",style:"Abstract",art:"sun"},
 {id:5,name:"Mountain line",style:"Fine line",art:"mountain"},
 {id:6,name:"Olive branch",style:"Nature",art:"branch"},
 {id:7,name:"Lucky star",style:"Traditional",art:"star"},
 {id:8,name:"Sacred orbit",style:"Abstract",art:"orbit"}
];
const art = {
 moon:'<circle cx="50" cy="35" r="20"/><path d="M53 15 A20 20 0 1 0 68 48 A17 17 0 0 1 53 15Z"/><path d="M15 76h70M25 83h50"/>',
 rose:'<path d="M50 75C28 61 22 45 39 34c5-4 11-3 13 2 5-11 20-8 21 4 2 13-12 24-23 35Z"/><path d="M50 74c-3 8-4 13-2 18M48 82c-13-7-18-5-23-1 10 1 16 4 22 7M51 78c10-9 19-8 24-5-9 5-16 8-24 11"/><path d="M43 39c7 2 11 7 9 13M56 32c-2 6-1 10 4 13"/>',
 snake:'<path d="M30 18c30-12 43 14 22 28S28 70 53 78s30-12 16-18"/><path d="M28 18l-8-4 3 10M28 18l8-7M66 60l9-4-2 10M66 60l-7-6"/><circle cx="27" cy="18" r="1.5"/>',
 sun:'<circle cx="50" cy="50" r="17"/><path d="M50 12v15M50 73v15M12 50h15M73 50h15M23 23l11 11M66 66l11 11M77 23 66 34M34 66 23 77"/><path d="M50 40l4 8 9 2-7 6 1 9-7-5-8 5 2-9-7-6 9-2Z"/>',
 mountain:'<path d="M12 75 38 31l14 23 11-17 25 38Z"/><path d="m30 45 8-14 8 13M56 48l7-11 7 11M12 84h76"/>',
 branch:'<path d="M24 82C42 65 49 45 72 19"/><path d="M38 65C24 64 20 54 22 46c12 1 18 8 16 17ZM49 48c-1-13 8-20 19-21 1 12-7 20-19 21ZM61 32c-2-10 4-17 13-20 3 10-2 17-13 20ZM32 72c-10-1-16 4-18 12 10 2 17-3 18-12Z"/>',
 star:'<path d="m50 12 10 25 27 2-21 17 7 26-23-15-23 15 7-26L13 39l27-2Z"/><path d="M50 29v42M30 43l40 14M70 43 30 57"/>',
 orbit:'<circle cx="50" cy="50" r="8"/><ellipse cx="50" cy="50" rx="37" ry="17" transform="rotate(35 50 50)"/><ellipse cx="50" cy="50" rx="37" ry="17" transform="rotate(-35 50 50)"/><circle cx="80" cy="33" r="3"/>'
};
let activeFilter="All";
let saved=new Set(JSON.parse(localStorage.getItem("yts-saved")||"[]"));
function render(){
 const grid=document.getElementById("designGrid");
 const filtered=designs.filter(d=>activeFilter==="All"||d.style===activeFilter);
 grid.innerHTML=filtered.map(d=>`<article class="design-card"><div class="design-art"><svg viewBox="0 0 100 100" aria-label="${d.name} tattoo illustration">${art[d.art]}</svg><button class="heart ${saved.has(d.id)?"saved":""}" aria-label="${saved.has(d.id)?"Unsave":"Save"} ${d.name}" data-save="${d.id}">${saved.has(d.id)?"♥":"♡"}</button></div><div class="design-info"><strong>${d.name}</strong><span>${d.style}</span></div></article>`).join("");
 grid.querySelectorAll("[data-save]").forEach(btn=>btn.addEventListener("click",()=>{const id=Number(btn.dataset.save);saved.has(id)?saved.delete(id):saved.add(id);localStorage.setItem("yts-saved",JSON.stringify([...saved]));render();renderSaved()}));
}
function renderSaved(){
 const list=document.getElementById("savedList");const items=designs.filter(d=>saved.has(d.id));
 list.innerHTML=items.length?items.map(d=>`<span class="saved-chip">${d.name} · ${d.style}</span>`).join(""):'<p class="muted">Tap the heart on a design to save it here.</p>';
}
document.querySelectorAll("[data-filter]").forEach(btn=>btn.addEventListener("click",()=>{activeFilter=btn.dataset.filter;document.querySelectorAll("[data-filter]").forEach(b=>b.classList.toggle("active",b===btn));render()}));
const photoInput=document.getElementById("photoInput"), previewWrap=document.getElementById("previewWrap"), photoPreview=document.getElementById("photoPreview");
let photoUrl=null;
photoInput.addEventListener("change",()=>{const file=photoInput.files?.[0];if(!file)return;if(!file.type.startsWith("image/")){alert("Please choose an image file.");return}if(photoUrl)URL.revokeObjectURL(photoUrl);photoUrl=URL.createObjectURL(file);photoPreview.src=photoUrl;previewWrap.hidden=false;});
document.getElementById("removePhoto").addEventListener("click",()=>{photoInput.value="";photoPreview.removeAttribute("src");previewWrap.hidden=true;if(photoUrl)URL.revokeObjectURL(photoUrl);photoUrl=null;});
document.getElementById("nearbyBtn").addEventListener("click",()=>{
 const status=document.getElementById("locationStatus");
 if(!navigator.geolocation){status.textContent="Location isn't supported in this browser. You can search your city directly on OpenStreetMap.";return}
 status.textContent="Requesting your location…";
 navigator.geolocation.getCurrentPosition(pos=>{const {latitude,longitude}=pos.coords;status.textContent="Opening a map search near your location.";window.open(`https://www.openstreetmap.org/#map=14/${latitude}/${longitude}`, "_blank","noopener");},err=>{status.textContent=err.code===1?"Location permission was declined. You can still search a city manually on OpenStreetMap.":"Couldn't get your location. Try again or search a city manually on OpenStreetMap.";},{timeout:10000,maximumAge:60000});
});
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
render();renderSaved();
