# Your Tattoo Studio — free starter prototype

This is a beginner-friendly, no-subscription starter web app. It includes:
- Responsive dark tattoo-inspired design
- Example tattoo illustrations and style filters
- Saved designs (stored in the browser)
- Local photo preview (the photo is not uploaded)
- Location permission button that opens OpenStreetMap
- Basic installable-web-app files

## Run it locally
1. Unzip the folder.
2. Open `index.html` in a browser for basic testing.
3. For location and install/offline features, serve it over HTTPS or localhost. One simple option is Visual Studio Code with the free Live Server extension.

## Free hosting option: GitHub Pages
1. Create a free account at https://github.com/
2. Create a public repository named `your-tattoo-studio`.
3. Upload the files in this folder to the repository root.
4. Open repository Settings → Pages.
5. Choose deploy from the `main` branch and `/ (root)`, then save.
6. GitHub will provide a public HTTPS website address.

## Important limits
This is a prototype, not a finished commercial app. It does not yet include accounts, cloud storage, real appointment booking, a 3D body/avatar engine, tattoo tracking on a body, or a curated live studio database. The map button opens a general map centered on the user's location; it does not verify which studios are open or available. Browser geolocation requires permission and usually HTTPS.

## Keep costs at $0
- Hosting: GitHub Pages free tier (public repository).
- Map: OpenStreetMap map link; respect the provider's usage policies if adding map tiles or search APIs.
- Photo preview: processed locally in the browser.
- Design: included sample SVG illustrations.
- App stores: publishing native iOS apps generally requires an Apple Developer Program membership; Google Play has a one-time developer registration fee. A web app/PWA avoids app-store fees.
- Advanced photo-to-3D generation and reliable booking integrations may require paid services or substantial custom development.
